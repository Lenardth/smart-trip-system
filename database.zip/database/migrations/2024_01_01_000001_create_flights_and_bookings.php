<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Flights table
        if (!Schema::hasTable('flights')) {
            Schema::create('flights', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->constrained()->onDelete('cascade');
                $table->string('flight_number');
                $table->string('airline');
                $table->string('departure_city');
                $table->string('arrival_city');
                $table->dateTime('departure_time');
                $table->dateTime('arrival_time');
                $table->decimal('price', 10, 2);
                $table->integer('seats_available');
                $table->enum('class', ['economy', 'business', 'first']);
                $table->text('description')->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        }

        // Bookings table
        if (!Schema::hasTable('bookings')) {
            Schema::create('bookings', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->constrained()->onDelete('cascade');
                $table->foreignId('flight_id')->constrained()->onDelete('cascade');
                $table->integer('passenger_count')->default(1);
                $table->decimal('total_price', 10, 2);
                $table->enum('status', ['pending', 'confirmed', 'cancelled'])->default('pending');
                $table->string('booking_reference')->unique();
                $table->json('passenger_details')->nullable();
                $table->text('special_requests')->nullable();
                $table->timestamps();
            });
        }

        // Add similar checks for other tables...
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('agency_profiles');
        Schema::dropIfExists('user_preferences');
        Schema::dropIfExists('memory_frames');
        Schema::dropIfExists('memories');
        Schema::dropIfExists('bookings');
        Schema::dropIfExists('flights');
    }
};
